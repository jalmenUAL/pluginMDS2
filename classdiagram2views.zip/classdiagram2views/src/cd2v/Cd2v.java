package cd2v;

import com.vp.plugin.VPPlugin;
import com.vp.plugin.VPPluginInfo;

public class Cd2v implements VPPlugin {

	@Override
	public void loaded(VPPluginInfo arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void unloaded() {
		// TODO Auto-generated method stub

	}

}
